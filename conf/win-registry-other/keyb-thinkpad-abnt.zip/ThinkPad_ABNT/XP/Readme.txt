 1)  Type "Portcode /Enable" when enabling scan code mapping.
      Once the registry update is done, show a message of "Key is enabled. Please restart the computer"

 2) Type "Portcode /Disable" when disabling scan code mapping. 
      Once the registry update is done, show a message of "Key is disabled. Please restart the computer"
